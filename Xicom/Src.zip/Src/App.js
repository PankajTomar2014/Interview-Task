import React from 'react';
import {RootStack} from './Navigation/Naviagtor';

export default App = () => {
  return <RootStack />;
};
